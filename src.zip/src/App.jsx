import React, { useState, useRef } from 'react';
import MediaPlayerDocs from './components/MediaPlayerDocs';

function App() {
  

  return <MediaPlayerDocs />
}

export default App;